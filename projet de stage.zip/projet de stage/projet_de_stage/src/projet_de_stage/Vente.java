/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_de_stage;

import BDD.Parameter;
import BDD.db_connexion;
import BDD.errorges;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author midek
 */
public class Vente extends javax.swing.JFrame {
    
    db_connexion db;
    Connection con;
    PreparedStatement prst;
    ResultSet rst;
    int old,now,dec;
    Double total = 0.0;
   
     private String  date;
     
    public Vente() {
       
        initComponents();
        
         ArrayList<String> list=new ArrayList<String>();
        String sql = "SELECT designation FROM produit ;";
        try{
            ScriptConnect();
            Statement state = (Statement) con.createStatement();
            rst = state.executeQuery(sql);
            String s = new String();
            while(rst.next()){
                s=rst.getString("designation");
                list.add(s);
            }
            con.close();
            for(int i=0;i<=list.size();i++){
                cmbproduit.addItem(list.get(i));
            }
        }catch(Exception e){
        System.out.println(e.getMessage());
        }
        
         db = new db_connexion(new Parameter().HOST_DB, new Parameter().USERNAME_DB, new Parameter().PASSWORD_DB, new Parameter().IPHOST, new Parameter().PORT);
     
    }
     public void table() {
        String v[] = {"id_vente","date_vente","num_vente","designation","prix","stocks","quantite","montant","reste_stock","payer"};
        rst = db.querySelect(v, "vente");
        table3.setModel(new errorges(rst));
    }
     void actualiser() {
        date.setText("");
        numv.setText("");
        cmbproduit.setSelectedItem("designation");
        txtprix.setText("");
        tock.setText("");
        nbre.setText("");
        mont.setText("");
        rstock.setText("");
        pay.setText("");
       
     }
      public void ScriptConnect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/stage_projet","root","");
            //JOptionPane.showMessageDialog(null, "Connexion réussie");
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmbproduit = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnajouter = new javax.swing.JButton();
        exit2 = new javax.swing.JButton();
        deconnexion = new javax.swing.JButton();
        nbre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtprix = new javax.swing.JLabel();
        tock = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        numv = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pay = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        table3 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        rstock = new javax.swing.JLabel();
        date = new javax.swing.JFormattedTextField();
        jLabel10 = new javax.swing.JLabel();
        mont = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        idprod = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        cmbproduit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbproduit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbproduitActionPerformed(evt);
            }
        });
        getContentPane().add(cmbproduit);
        cmbproduit.setBounds(140, 157, 150, 30);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Gestion de Vente d'articles");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(300, 10, 410, 42);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText(" PRODUIT :");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(24, 156, 110, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("   PRIX :");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(60, 240, 80, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Montant :");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 420, 100, 30);

        btnajouter.setBackground(new java.awt.Color(0, 0, 0));
        btnajouter.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        btnajouter.setForeground(new java.awt.Color(204, 204, 255));
        btnajouter.setText("Enregistrer");
        btnajouter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnajouterActionPerformed(evt);
            }
        });
        getContentPane().add(btnajouter);
        btnajouter.setBounds(700, 270, 130, 40);

        exit2.setBackground(new java.awt.Color(0, 0, 0));
        exit2.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        exit2.setForeground(new java.awt.Color(204, 204, 255));
        exit2.setText("Reçu");
        exit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit2ActionPerformed(evt);
            }
        });
        getContentPane().add(exit2);
        exit2.setBounds(1020, 270, 100, 40);

        deconnexion.setBackground(new java.awt.Color(0, 0, 0));
        deconnexion.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        deconnexion.setForeground(new java.awt.Color(204, 204, 255));
        deconnexion.setText("Deconnexion");
        deconnexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deconnexionActionPerformed(evt);
            }
        });
        getContentPane().add(deconnexion);
        deconnexion.setBounds(970, 490, 150, 40);

        nbre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nbreKeyReleased(evt);
            }
        });
        getContentPane().add(nbre);
        nbre.setBounds(140, 340, 170, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("RESTE_STOCK :");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 480, 150, 33);

        txtprix.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(txtprix);
        txtprix.setBounds(140, 240, 124, 30);

        tock.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(tock);
        tock.setBounds(150, 300, 124, 33);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("n° de Vente :");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(26, 98, 120, 40);

        numv.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(numv);
        numv.setBounds(150, 98, 130, 40);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setText("Date :");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(64, 48, 70, 39);

        jLabel8.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel8.setText("Payer :");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(400, 270, 71, 40);

        pay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(pay);
        pay.setBounds(470, 270, 125, 40);

        table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "id_vente", "date_vente", "num_vente", "designation", "prix", "stocks", "quantite", "montant", "reste en stoc", "Payer"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        table3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table3MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table3);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(314, 83, 840, 120);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("NOMBRE :");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(40, 340, 100, 30);

        rstock.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        rstock.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                rstockKeyReleased(evt);
            }
        });
        getContentPane().add(rstock);
        rstock.setBounds(150, 480, 130, 40);

        try {
            date.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        date.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(date);
        date.setBounds(130, 50, 140, 30);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("STOCK :");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(60, 300, 85, 33);

        mont.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        mont.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                montKeyReleased(evt);
            }
        });
        getContentPane().add(mont);
        mont.setBounds(130, 420, 130, 40);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("id :");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(80, 194, 28, 30);

        idprod.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(idprod);
        idprod.setBounds(140, 194, 80, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbproduitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbproduitActionPerformed

        String sql = "SELECT prix,stock,id FROM produit WHERE designation = '"+cmbproduit.getSelectedItem().toString()+"';";
        String[] afficher = new String[2];
        String[] affiche = new String[2];
        String[] affich = new String[2];
        try{
            ScriptConnect();
            Statement state = (Statement) con.createStatement();
            rst = state.executeQuery(sql);
            if(rst.next()){
                afficher[0]=rst.getString("prix");
                affiche[0]=rst.getString("stock");
                affich[0]=rst.getString("id");
                
            }
            con.close();
            txtprix.setText(afficher[0]);
            tock.setText(affiche[0]);
            idprod.setText(affich[0]);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
       
    }//GEN-LAST:event_cmbproduitActionPerformed

    private void btnajouterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnajouterActionPerformed
        
        if (date.getText().equals("") || numv.getText().equals("") || txtprix.getText().equals("")|| tock.getText().equals("")|| nbre.getText().equals("")|| rstock.getText().equals("")|| pay.getText().equals("")) {
             JOptionPane.showMessageDialog(this, "informations incomplete");
        } else if (date.getText().equals("") || numv.getText().equals("") || txtprix.getText().equals("")|| tock.getText().equals("")|| nbre.getText().equals("")|| rstock.getText().equals("")|| pay.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "erreur de saisie");}
        else{
            String[] colon = {"date_vente","num_vente","designation","prix","stocks","quantite","montant","reste_stock","payer"};
            String[] inf = {date.getText (),numv.getText(),cmbproduit.getSelectedItem().toString(),txtprix.getText(),tock.getText(),nbre.getText(),mont.getText(),rstock.getText(),pay.getText()};
            System.out.println(db.queryInsert("vente", colon, inf));
            
            table();
            actualiser();
           
        }
       
        try {
            nvtok();
        } catch (SQLException ex) {
            Logger.getLogger(Vente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            
       
         JFrame frame = new JFrame();
                    JOptionPane.showMessageDialog(this,
                    "vente effectué et enregistré."); 
      
    }//GEN-LAST:event_btnajouterActionPerformed

    private void exit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit2ActionPerformed
        reçu r =new reçu();
       r.setVisible(true);
    }//GEN-LAST:event_exit2ActionPerformed

    private void deconnexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deconnexionActionPerformed
        int p= JOptionPane.showConfirmDialog(null, "Voulez vous quitter", "Quitter", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

        if (p == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }//GEN-LAST:event_deconnexionActionPerformed

    private void table3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table3MouseClicked
 
    }//GEN-LAST:event_table3MouseClicked

    private void nbreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nbreKeyReleased
      subtotal();
      rsttotal();
    }//GEN-LAST:event_nbreKeyReleased

    private void rstockKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rstockKeyReleased
        
    }//GEN-LAST:event_rstockKeyReleased

    private void montKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_montKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_montKeyReleased

    /**
     * @param args the command line arguments
     */
    public void subtotal() {
        double a = Double.parseDouble(txtprix.getText());
        double b = Double.parseDouble(nbre.getText());
        double c = a * b;
        mont.setText(String.valueOf(c));}
    
    public void rsttotal(){
       int a = Integer.parseInt(tock.getText());
        int b = Integer.parseInt(nbre.getText());
        int c = a - b;
        rstock.setText(Integer.toString(c));
    }
    
     public int nvtok() throws SQLException {
        rst = db.querySelectAll("produit", "id='" + idprod.getText() + "'");
        while (rst.next()) {
            old = rst.getInt("stock");
        }
        dec = Integer.parseInt(nbre.getText());
        now = old - dec;
         String nvstock = Integer.toString(now);

        String a = String.valueOf(nvstock);
        String[] colon = {"stock"};
        String[] isi = {a};
        System.out.println(db.queryUpdate("produit", colon, isi, "id='" + idprod.getText() + "'"));
        return 0;
    }
    
     
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnajouter;
    private javax.swing.JComboBox<String> cmbproduit;
    private javax.swing.JFormattedTextField date;
    private javax.swing.JButton deconnexion;
    private javax.swing.JButton exit2;
    private javax.swing.JLabel idprod;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel mont;
    private javax.swing.JTextField nbre;
    private javax.swing.JTextField numv;
    private javax.swing.JTextField pay;
    private javax.swing.JLabel rstock;
    private javax.swing.JTable table3;
    private javax.swing.JLabel tock;
    private javax.swing.JLabel txtprix;
    // End of variables declaration//GEN-END:variables
}
