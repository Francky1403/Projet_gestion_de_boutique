/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_de_stage;

import BDD.Parameter;
import BDD.db_connexion;
import BDD.errorges;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author midek
 */
public class produit extends javax.swing.JFrame {

      ResultSet rst;
    db_connexion db;
    public produit() {
        db = new db_connexion(new Parameter().HOST_DB, new Parameter().USERNAME_DB, new Parameter().PASSWORD_DB, new Parameter().IPHOST, new Parameter().PORT);
        initComponents();
        table();
    }
    public void table() {
        String t[] = {"id","code_produit","designation","prix","stock"};
        rst = db.querySelect(t, "produit");
        table2.setModel(new errorges(rst));
    }
     void actualiser() {
        codeprod.setText("");
        des.setText("");
        prix.setText("");
        stock.setText("");
       
     }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        ajouter1 = new javax.swing.JButton();
        modifier1 = new javax.swing.JButton();
        supprimer1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        categorie1 = new javax.swing.JComboBox<>();
        rechercher1 = new javax.swing.JButton();
        rech = new javax.swing.JTextField();
        deconnexion1 = new javax.swing.JButton();
        exit1 = new javax.swing.JButton();
        stock = new javax.swing.JTextField();
        prix = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        des = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        codeprod = new javax.swing.JTextField();
        actualiser1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "id", "code_produit", "designation", "prix", "stock"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table2);

        jLabel2.setFont(new java.awt.Font("Verdana", 3, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("Produit");

        ajouter1.setBackground(new java.awt.Color(0, 0, 0));
        ajouter1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        ajouter1.setForeground(new java.awt.Color(204, 204, 255));
        ajouter1.setText("Ajouter");
        ajouter1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ajouter1ActionPerformed(evt);
            }
        });

        modifier1.setBackground(new java.awt.Color(0, 0, 0));
        modifier1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        modifier1.setForeground(new java.awt.Color(204, 204, 255));
        modifier1.setText("modifier");
        modifier1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifier1ActionPerformed(evt);
            }
        });

        supprimer1.setBackground(new java.awt.Color(0, 0, 0));
        supprimer1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        supprimer1.setForeground(new java.awt.Color(204, 204, 255));
        supprimer1.setText("supprimer");
        supprimer1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supprimer1ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 255));
        jLabel5.setText("categorie");

        categorie1.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        categorie1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "code_produit", "designation", "prix", "stock", " " }));
        categorie1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categorie1ActionPerformed(evt);
            }
        });

        rechercher1.setBackground(new java.awt.Color(0, 0, 0));
        rechercher1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        rechercher1.setForeground(new java.awt.Color(204, 204, 255));
        rechercher1.setText("rechercher");
        rechercher1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rechercher1ActionPerformed(evt);
            }
        });

        rech.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N

        deconnexion1.setBackground(new java.awt.Color(0, 0, 0));
        deconnexion1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        deconnexion1.setForeground(new java.awt.Color(204, 204, 255));
        deconnexion1.setText("Deconnexion");
        deconnexion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deconnexion1ActionPerformed(evt);
            }
        });

        exit1.setBackground(new java.awt.Color(0, 0, 0));
        exit1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        exit1.setForeground(new java.awt.Color(204, 204, 255));
        exit1.setText("Exit");
        exit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit1ActionPerformed(evt);
            }
        });

        stock.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N

        prix.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 255));
        jLabel7.setText("           prix :");

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 102, 255));
        jLabel8.setText(" stock :");

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(102, 102, 255));
        jLabel9.setText("designation :");

        des.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 102, 255));
        jLabel10.setText("code_produit :");

        codeprod.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N

        actualiser1.setBackground(new java.awt.Color(0, 0, 0));
        actualiser1.setFont(new java.awt.Font("Candara Light", 1, 18)); // NOI18N
        actualiser1.setForeground(new java.awt.Color(204, 204, 255));
        actualiser1.setText("actualiser");
        actualiser1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualiser1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(ajouter1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addComponent(modifier1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addComponent(supprimer1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(actualiser1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(591, 591, 591)
                        .addComponent(deconnexion1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(codeprod, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(72, 72, 72)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(exit1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(des, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(prix, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                            .addComponent(stock))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(255, 255, 255))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap(512, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(categorie1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(rechercher1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, 0)
                            .addComponent(rech, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(0, 8, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(actualiser1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(supprimer1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modifier1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ajouter1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(codeprod, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(stock, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(des, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(prix, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(deconnexion1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exit1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap(282, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(categorie1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(20, 20, 20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(rechercher1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(rech, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 139, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void table2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table2MouseClicked
        codeprod.setText(String.valueOf(table2.getValueAt(table2.getSelectedRow(), 1)));
        
        des.setText(String.valueOf(table2.getValueAt(table2.getSelectedRow(), 2)));
        prix.setText(String.valueOf(table2.getValueAt(table2.getSelectedRow(), 3)));
        stock.setText(String.valueOf(table2.getValueAt(table2.getSelectedRow(), 4)));
      
    }//GEN-LAST:event_table2MouseClicked

    private void ajouter1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ajouter1ActionPerformed
        if (codeprod.getText().equals("") || des.getText().equals("") || prix.getText().equals("") || stock.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "informations incomplete");
        } else if (codeprod.getText().equals("") || des.getText().equals("") || prix.getText().equals("") || stock.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "erreur de saisie");}
        else{
            String[] colon = {"code_produit", "designation","prix","stock",};
            String[] inf = {codeprod.getText(),des.getText(),prix.getText(),stock.getText()};
            System.out.println(db.queryInsert("produit", colon, inf));
            JOptionPane.showMessageDialog(this, "Ajout effectué avec succès");
            table();
            actualiser();
        }
    }//GEN-LAST:event_ajouter1ActionPerformed

    private void modifier1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifier1ActionPerformed
        if (codeprod.getText().equals("")  || des.getText().equals("") || prix.getText().equals("")|| stock.getText().equals("")) {
            JOptionPane.showMessageDialog(this, " informations incomplete");
        } else {
            String[] colon = {"code_produit","designation","prix","stock"};
            String[] inf = {codeprod.getText(),des.getText(),prix.getText(),stock.getText()};
            String id = String.valueOf(table2.getValueAt(table2.getSelectedRow(), 0));
            System.out.println(db.queryUpdate("produit", colon, inf, "id='" + id + "'"));
            JOptionPane.showMessageDialog(this, " Modification effectuée avec succès");
            table();
            actualiser();
        }
    }//GEN-LAST:event_modifier1ActionPerformed

    private void supprimer1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supprimer1ActionPerformed
        String id = String.valueOf(table2.getValueAt(table2.getSelectedRow(), 0));
        if (JOptionPane.showConfirmDialog(this, "êtes vous sure de vouloir supprimer ", "attention!!!", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            db.queryDelete("produit", "id=" + id);
        } else {
            return;
        }
        table();
    }//GEN-LAST:event_supprimer1ActionPerformed

    private void rechercher1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rechercher1ActionPerformed
        if (rech.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "entrer les données");
        } else {
            if (categorie1.getSelectedItem().equals("code_produit")) {
                rst = db.querySelectAll("produit", "code_produit LIKE '%" + rech.getText() + "%' ");
                table2.setModel(new errorges(rst));
            } else if (categorie1.getSelectedItem().equals("designation")) {
                rst = db.querySelectAll("produit", "deseignation LIKE '%" + rech.getText() + "%' ");
                table2.setModel(new errorges(rst));
            } else if (categorie1.getSelectedItem().equals("prix")) {
                rst = db.querySelectAll("produit", "prix LIKE '%" + rech.getText() + "%' ");
                table2.setModel(new errorges(rst));
            } else if (categorie1.getSelectedItem().equals("stock")) {
                rst = db.querySelectAll("produit", "stock LIKE '%" + rech.getText() + "%' ");
                table2.setModel(new errorges(rst));
            } 
        }
    }//GEN-LAST:event_rechercher1ActionPerformed

    private void deconnexion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deconnexion1ActionPerformed
        int p= JOptionPane.showConfirmDialog(null, "Voulez vous quitter", "Quitter", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);

        if (p == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }//GEN-LAST:event_deconnexion1ActionPerformed

    private void exit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit1ActionPerformed
       Menu_Admin ma= new Menu_Admin();
        ma.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_exit1ActionPerformed

    private void actualiser1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualiser1ActionPerformed
       actualiser(); table();   
    }//GEN-LAST:event_actualiser1ActionPerformed

    private void categorie1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categorie1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_categorie1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(produit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(produit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(produit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(produit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new produit().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualiser1;
    private javax.swing.JButton ajouter1;
    private javax.swing.JComboBox<String> categorie1;
    private javax.swing.JTextField codeprod;
    private javax.swing.JButton deconnexion1;
    private javax.swing.JTextField des;
    private javax.swing.JButton exit1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modifier1;
    private javax.swing.JTextField prix;
    private javax.swing.JTextField rech;
    private javax.swing.JButton rechercher1;
    private javax.swing.JTextField stock;
    private javax.swing.JButton supprimer1;
    private javax.swing.JTable table2;
    // End of variables declaration//GEN-END:variables
}
